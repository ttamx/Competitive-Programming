#ifndef __STICK_H_INCLUDED__
#define __STICK_H_INCLUDED__

#include <vector>
void init(int N, std::vector<int> X);
int max_length(int L,int R);

#endif
