#include "stick.h"

void init(int N, std::vector<int> X){
  return;
}

int max_length(int L,int R){
  return 0;
}
