#include "rockpaperscissors.h"

int find_cheater1(int N){
  return 0;
}

int find_cheater2(int N){
  return 0;
}
