#ifndef __ROCKPAPERSCISSORS_H_INCLUDED__
#define __ROCKPAPERSCISSORS_H_INCLUDED__

#include <vector>
int tournament(std::vector<int>person_index);
int find_cheater1(int N);
int find_cheater2(int N);

#endif
