#include "symbols.h"

// edit this file as you like

int N;
int Q;

void explore_site(int N, int Q) {
  ::N = N;
  ::Q = Q;
}
int retrieve_notes(int L, int R) {
  int ret = 1;
  for (int i = 0; i < N; i++) {
    ret = (long long)ret * 26 % 20232566;
  }
  return ret;
}