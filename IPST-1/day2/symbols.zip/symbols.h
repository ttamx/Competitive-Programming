void explore_site(int N, int Q);
int retrieve_notes(int L, int R);