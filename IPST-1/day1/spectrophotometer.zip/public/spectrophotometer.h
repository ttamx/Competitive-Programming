void sort_lasers(int N);
bool call_swap(int a, int b);