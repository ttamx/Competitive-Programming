#include "spectrophotometer.h"

void sort_lasers(int N) {
  call_swap(0, 1);
  call_swap(1, 0);
}