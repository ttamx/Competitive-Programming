#include "magic.h"
#include <vector>
using namespace std;

vector<int> magic(int N, int M,int Q, vector<int>U, vector<int> V, vector<vector<int> >q){
  vector<int>ans;
  return ans;
}
