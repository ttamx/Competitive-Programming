#ifndef __MAGIC_H_INCLUDED__
#define __MAGIC_H_INCLUDED__

#include <vector>
std::vector<int> magic(int N, int M,int Q, std::vector<int>U, std::vector<int> V, std::vector<std::vector<int> >q);

#endif
