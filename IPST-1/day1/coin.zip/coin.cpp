#include "coin.h"
#include<vector>
void initialize(int N,std::vector<int> Rail,int L)
{
    return;
}
std::vector<int> max_dist(std::vector<std::vector<int> > Coins)
{
    std::vector<int> Ans;
    return Ans;
}
