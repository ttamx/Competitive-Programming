#include <vector>
void initialize(int N,std::vector<int>Rail,int L);
std::vector<int>max_dist(std::vector<std::vector<int> >Coins);
