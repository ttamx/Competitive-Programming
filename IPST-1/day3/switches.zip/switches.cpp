#include <vector>
long long minimum_energy(int N, int M, int K, std::vector<int> A, std::vector<int> L, 
                         std::vector<int> R, std::vector<int> C){
	return 0;
}
