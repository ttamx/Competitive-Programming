#include <vector>
std::vector<int> sort_tapes(int N, std::vector<int> A, std::vector<int> B) {
  std::vector<int> C;
  for (int i = 0; i < 2 * N; i++)
    C.push_back(i);
  return C;
}