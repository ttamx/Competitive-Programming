#ifndef __SORTINGTAPES_H_INCLUDED__
#define __SORTINGTAPES_H_INCLUDED__

#include <vector>
std::vector<int> sort_tapes(int N, std::vector<int> A, std::vector<int> B);
bool compare(int P, int Q);
#endif
